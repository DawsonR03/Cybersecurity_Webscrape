# MongoDB Integration for Vulnerability Scanner

This directory contains a Docker-based MongoDB integration for the Cybersecurity Vulnerability Scanner. It provides a simple way to store, query, and manage the scan results without requiring a full MongoDB installation.

## Features

- Containerized MongoDB instance using Docker
- Automatic file watcher that imports JSON data
- Simple search utility for querying stored results
- No manual database setup required

## Requirements

- [Docker](https://www.docker.com/products/docker-desktop/) installed on your system
- [Docker Compose](https://docs.docker.com/compose/install/) (usually included with Docker Desktop)
- [Node.js](https://nodejs.org/) for the search utility

## Setup and Usage

### Starting the MongoDB Container

1. Navigate to the MongoMockup directory:
   ```bash
   cd MongoMockup
   ```

2. Start the MongoDB container and file watcher:
   ```bash
   docker-compose up -d
   ```

   This starts two containers:
   - `local-mongo`: A MongoDB instance
   - `file-watcher`: A Node.js app that watches for new JSON files

3. Check that containers are running:
   ```bash
   docker ps
   ```

### Storing Data

The file watcher automatically monitors the `uploads` directory for new JSON files. Any JSON file placed in this directory will be automatically imported into MongoDB.

To manually import data:

1. Copy your JSON files to the `uploads` directory:
   ```bash
   cp ../output/*.json uploads/
   ```

2. The file watcher will detect these files and import them

### Searching Stored Data

The `search.js` script provides a simple interface for querying stored data:

1. Run the search utility:
   ```bash
   node search.js
   ```

2. Choose from the options:
   - Show all files
   - Search by filename
   - Search by field (e.g., name, category, etc.)

3. Exported results will be saved to the `outputs` directory

## Integration with Main Scanner

The main vulnerability scanner can directly integrate with this MongoDB setup:

1. Make sure the MongoDB container is running
2. Run the scanner without the `--disable-mongodb` flag:
   ```bash
   cd ..
   python scrape.py
   ```

3. Results will be automatically stored in MongoDB

## Stopping and Cleaning Up

To stop the containers:
```bash
docker-compose down
```

To completely remove all data and containers:
```bash
docker-compose down -v
```

## Troubleshooting

- **Connection Refused**: Make sure the MongoDB container is running
- **Permissions Issues**: Ensure the `uploads` directory is writable
- **Import Errors**: Check that your JSON files are valid

## Technical Details

- MongoDB runs on the default port 27017
- The file watcher uses Node.js streams for efficient processing
- All data is stored in the `fileUploader` database
- JSON files are stored in the `jsonFiles` collection 